throw new Error("Synthetic PageMaker365 rehearsal artifact is nondeployable.");
